#!/bin/sh
export PLAN9=/opt/plan9
export MANPATH="$MANPATH:/opt/plan9/man"
export PATH="$PATH:/opt/plan9/bin"
