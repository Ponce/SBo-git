
chroot . /sbin/depmod -a

