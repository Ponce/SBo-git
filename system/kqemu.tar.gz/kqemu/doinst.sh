/sbin/depmod -a
