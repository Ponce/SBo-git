chroot . sh /install/register.sh
rm -f install/register.sh
rmdir install 2>/dev/null
