#!/bin/sh
export PATH="${PATH}:/opt/diet/bin"
export MANPATH="${MANPATH}:/opt/diet/man"
