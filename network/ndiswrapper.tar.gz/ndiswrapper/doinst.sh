chroot . /sbin/depmod -a @VERSION@

