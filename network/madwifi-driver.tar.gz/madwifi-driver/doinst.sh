chroot . /sbin/depmod -ae @KERNEL@

