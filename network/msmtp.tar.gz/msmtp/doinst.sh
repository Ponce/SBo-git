chroot . /usr/bin/install-info /usr/info/msmtp.info.gz /usr/info/dir 2> /dev/null
