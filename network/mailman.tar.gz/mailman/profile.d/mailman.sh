#!/bin/sh
export PATH="$PATH:/opt/mailman/bin"
