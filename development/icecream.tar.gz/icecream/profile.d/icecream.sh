#!/bin/sh
export PATH=/opt/icecream/bin:$PATH
