if [ -x /usr/bin/kbuildsycoca4 ]; then
  /usr/bin/kbuildsycoca4
fi

