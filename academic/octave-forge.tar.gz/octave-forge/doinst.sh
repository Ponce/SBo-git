octave --silent --eval "pkg rebuild"
