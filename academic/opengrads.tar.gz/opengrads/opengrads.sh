#!/bin/sh
export PATH=${PATH}:/opt/opengrads/Contents
