ioUrbanTerror is not a Frozen Sand product and is not part of Urban Terror. It's a seperate 3rd party product by woekele.

ioUrbanTerror can be used instead of Quake 3 Arena to run Urban Terror 4.x on.

If you already own a full copy of Quake 3 Arena and want to continue using Punkbuster, you don't need ioUrbanTerror and can install/use Quake 3 Arena + Urban Terror. If you don't have Quake 3 Arena and/or don't care about Punkbuster, then you should use ioUrbanTerror. Don't forget to install Urban Terror 4.x after installing ioUrbanTerror.

A word of thanks to:
-The ioquake3 team, for providing a very good code base to work on.
-Hobbes, for helping me out a lot with creating this software.
-Nexu, helping out a lot as well.
-Illogical, for providing a very good looking logo.
-Frozen Sand, for creating Urban Terror and all the fun that comes with it.

Created by woekele. You should be able to reach me at #urbanterror on irc.enterthegame.com.

-------------------------------

ioUrbanTerror is licensed under the GPL. It is heavily based on the ioquake3 source code (www.ioquake3.org). The ioUrbanTerror source code is available at:

http://ftp.snt.utwente.nl/pub/games/urbanterror/iourbanterror/source

"Urban Terror" is a registered trademark of Frozen Sand LLC (http://www.frozensand.com). The name was used in "ioUrbanTerror" with their permission. The Urban Terror logo shown on the first and last screen of this installer, is copyrighted by Frozen Sand LLC.

"Quake 3 Arena" is a registered trademark of id Software (http://www.idsoftware.com).

"Punkbuster" is a registered trademark of Evenbalance, Inc. (www.evenbalance.com).

The logo used for ioUrbanTerror (as shown in the right upper corner of this installer) was created by limefest and recreated by illogical. The license for it is the Creative Commons Attribution-NonCommercial-NoDerivatives.

The creator of this software does not take any responsibility for whatever effect it may have on anything. Use at your own risk.