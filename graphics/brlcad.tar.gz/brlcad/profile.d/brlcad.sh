#!/bin/sh
# Add PATH for brlcad:
export PATH="$PATH:/opt/brlcad/bin"

