# Configure plugins (writes $prefix/lib/graphviz/config with available plugin
# information)
chroot . /usr/bin/dot -c
