c_rehash etc/ssl/certs 1> /dev/null
