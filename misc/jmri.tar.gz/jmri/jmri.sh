#!/bin/sh
export JMRI_HOME=/opt/jmri
