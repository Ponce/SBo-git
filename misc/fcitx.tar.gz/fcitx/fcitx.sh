#!/bin/sh
export GTK_IM_MODULE=xim
export XMODIFIERS="@im=fcitx"
export XIM=fcitx
export XIM_PROGRAM=fcitx

