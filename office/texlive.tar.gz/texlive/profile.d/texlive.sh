#!/bin/sh
# Add PATH and MANPATH for TeXlive:
PATH="$PATH:/usr/share/texmf/bin"
MANPATH="$MANPATH:/usr/share/texmf/doc/man"
